<template>
	<div class="main">
		<v-card class="wrapper">
			<router-view></router-view>
		</v-card>
	</div>
</template>

<script>
export default {};
</script>

<style>
</style>
